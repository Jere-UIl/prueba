import { useEffect, useRef } from 'react'

const VIDEO_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260328_083109_283f3553-e28f-428b-a723-d639c617eb2b.mp4'

const FADE_DURATION = 0.5 // seconds

export default function VideoBackground() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    // Continuously monitor currentTime / duration and drive opacity manually.
    const tick = () => {
      const { currentTime, duration } = video

      if (duration && !Number.isNaN(duration)) {
        let opacity = 1

        if (currentTime < FADE_DURATION) {
          // Fade in over the first 0.5s
          opacity = currentTime / FADE_DURATION
        } else if (currentTime > duration - FADE_DURATION) {
          // Fade out over the last 0.5s
          opacity = Math.max(0, (duration - currentTime) / FADE_DURATION)
        }

        video.style.opacity = String(Math.min(1, Math.max(0, opacity)))
      }

      rafRef.current = requestAnimationFrame(tick)
    }

    rafRef.current = requestAnimationFrame(tick)

    // Manual seamless loop: on end, hide, reset, and replay.
    const handleEnded = () => {
      video.style.opacity = '0'
      window.setTimeout(() => {
        video.currentTime = 0
        video.play().catch(() => {
          /* autoplay may be blocked until user interaction; ignore */
        })
      }, 100)
    }

    video.addEventListener('ended', handleEnded)
    video.play().catch(() => {})

    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current)
      video.removeEventListener('ended', handleEnded)
    }
  }, [])

  return (
    <div className="absolute inset-0 z-0 overflow-hidden">
      <video
        ref={videoRef}
        src={VIDEO_URL}
        autoPlay
        muted
        loop={false}
        playsInline
        preload="auto"
        style={{
          position: 'absolute',
          inset: 'auto 0 0 0',
          top: '300px',
          width: '100%',
          height: 'auto',
          objectFit: 'cover',
          opacity: 0,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background" />
    </div>
  )
}
