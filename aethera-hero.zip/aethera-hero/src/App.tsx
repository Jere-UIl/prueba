import Navbar from './components/Navbar'
import Hero from './components/Hero'
import VideoBackground from './components/VideoBackground'

function App() {
  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-background">
      <VideoBackground />
      <Navbar />
      <Hero />
    </div>
  )
}

export default App
